"""vlm_agent: self-contained local scene-report agent. Delete this folder to remove it; the dashboard keeps working without it.

Hooks used by the rest of the project (all guarded with try/except at the call sites):
  vlm_agent.start()            -> start the resident model server (non-blocking)
  vlm_agent.analyze(event_dir, meta, report)  -> analyzer-cascade entry, adds report['scene']
  vlm_agent.status()           -> dict for the dashboard GPU panel
"""
import json
import os

from . import agent, server


def start():
    return server.start()


def status():
    return dict(server.STATE)


def analyze(event_dir, meta, report):
    if not server.STATE.get("loaded"):
        report["sections"]["Scene report (VLM)"] = "skipped: model " + server.STATE.get("state", "not available")
        return
    import time
    t = time.time()
    rep = agent.analyze_chunk(event_dir, meta)
    server.STATE.update(analyzed=server.STATE["analyzed"] + 1, last_s=round(time.time() - t, 2))
    with open(os.path.join(event_dir, "scene.json"), "w") as fh:
        json.dump(rep, fh, indent=1)
    report["scene"] = rep
    report["sections"]["Scene report (%s)" % rep["model"].split("/")[-1]] = agent.to_markdown(rep)
    if rep["summary"]:
        report["summary"] = rep["summary"]
