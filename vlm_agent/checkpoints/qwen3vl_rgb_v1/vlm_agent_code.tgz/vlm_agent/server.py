"""Resident llama-server (Qwen3-VL-2B Q4_K_M + mmproj): started once, kept loaded while idle, restarted if it dies."""
import atexit
import base64
import ctypes
import json
import os
import signal
import subprocess
import threading
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(HERE, "third_party", "llama.cpp", "build", "bin", "llama-server")
MANIFEST = os.path.join(HERE, "models", "manifest.json")
PORT = 8089
URL = f"http://127.0.0.1:{PORT}"
# serving settings (spec section 6): one model, one slot, small context, deterministic
CTX = 4096
MAX_NEW_TOKENS = 256

STATE = dict(name="Qwen3-VL-2B Q4_K_M", state="not started", loaded=False, busy=False, analyzed=0, last_s=0.0, error="",
             restarts=0, vram_mib=None, queued=0)
GPU_LOCK = threading.Lock()          # exactly one request on the GPU at a time
_proc = None
_stop = False


def available():
    return os.path.exists(BIN) and os.path.exists(MANIFEST)


def _paths():
    m = json.load(open(MANIFEST))
    fs = list(m["files"].values())
    model = next(f["path"] for f in fs if not os.path.basename(f["path"]).startswith("mmproj"))
    proj = next(f["path"] for f in fs if os.path.basename(f["path"]).startswith("mmproj"))
    return model, proj


PIDFILE = os.path.join(HERE, "logs", "llama-server.pid")


def _kill_stale():
    """A llama-server left behind by an earlier dashboard run would hold the port (and must not be reused: unknown settings)."""
    try:
        pid = int(open(PIDFILE).read())
        if "llama-server" in open(f"/proc/{pid}/cmdline").read():
            os.kill(pid, signal.SIGTERM)
            for _ in range(50):
                if not os.path.exists(f"/proc/{pid}"):
                    break
                time.sleep(0.1)
    except (OSError, ValueError):
        pass


def _die_with_parent():
    ctypes.CDLL("libc.so.6").prctl(1, signal.SIGTERM)    # PR_SET_PDEATHSIG: the child dies when the dashboard dies


def _spawn():
    global _proc
    _kill_stale()
    model, proj = _paths()
    log = open(os.path.join(HERE, "logs", "llama-server.log"), "ab")
    cmd = [BIN, "-m", model, "--mmproj", proj, "-ngl", "99", "-c", str(CTX), "--parallel", "1", "--host", "127.0.0.1", "--port", str(PORT),
           "--temp", "0", "-n", str(MAX_NEW_TOKENS), "--no-webui", "--cache-ram", "0"]
    _proc = subprocess.Popen(cmd, stdout=log, stderr=log, preexec_fn=_die_with_parent)
    open(PIDFILE, "w").write(str(_proc.pid))
    STATE.update(state="loading model", loaded=False)


def healthy():
    try:
        with urllib.request.urlopen(URL + "/health", timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def chat(messages, max_tokens=MAX_NEW_TOKENS, timeout=180):
    """One stateless chat completion. messages: OpenAI-style list (images as data: URLs)."""
    body = json.dumps(dict(messages=messages, max_tokens=max_tokens, temperature=0, stream=False, cache_prompt=False)).encode()
    req = urllib.request.Request(URL + "/v1/chat/completions", data=body, headers={"content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        out = json.loads(r.read())
    return out["choices"][0]["message"]["content"].strip(), out.get("usage", {})


def _warm():
    import cv2
    import numpy as np
    img = np.full((224, 224, 3), 127, np.uint8)
    ok, jpg = cv2.imencode(".jpg", img)
    url = "data:image/jpeg;base64," + base64.b64encode(jpg.tobytes()).decode()
    chat([{"role": "user", "content": [{"type": "text", "text": "Describe this image in one short sentence."},
                                       {"type": "image_url", "image_url": {"url": url}}]}], max_tokens=16)


def _supervisor():
    global _stop
    fails = 0
    while not _stop:
        if _proc is None or _proc.poll() is not None:
            if _proc is not None:
                STATE["restarts"] += 1
                STATE.update(state="crashed, restarting", loaded=False)
                fails += 1
                if fails > 3:
                    STATE.update(state="failed (see vlm_agent/logs/llama-server.log)", error="llama-server keeps exiting")
                    return
            try:
                _spawn()
            except Exception as e:
                STATE.update(state="failed", error=repr(e)); return
        if not STATE["loaded"] and _proc is not None and _proc.poll() is None and healthy():
            try:
                _warm()
                STATE.update(state="idle (model resident, waiting for a chunk)", loaded=True, error="")
                fails = 0
            except Exception as e:
                STATE["error"] = "warm-up: " + repr(e)
        time.sleep(1.0)


def start():
    """Start the supervisor thread (non-blocking). Returns False if the runtime/models are not installed."""
    if not available():
        STATE.update(state="not installed (run vlm_agent/setup.sh)")
        return False
    threading.Thread(target=_supervisor, daemon=True).start()
    return True


atexit.register(lambda: _proc and _proc.poll() is None and _proc.terminate())


def stop():
    global _stop
    _stop = True
    if _proc and _proc.poll() is None:
        _proc.terminate()
