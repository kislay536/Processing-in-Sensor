"""Scene-report agent (RGB mode wired; thermal / rgb_audio are defined but not fed by the board yet).

analyze_chunk(event_dir, meta, baseline) -> report dict (README section 8 shape):
  validate frames -> 4 s windows, <= 4 frames each (evenly spaced), long edge 336 px -> one stateless request per window
  -> text-only synthesis if more than one window -> JSON + Markdown. Failures shorten the window / shrink frames, never
  fall back to a text-only guess.
"""
import base64
import datetime as dt
import os
import subprocess
import threading
import time

import cv2

from . import prompts, server

WINDOW_S = 4.0
MAX_FRAMES = 4
LONG_EDGE = 336
MODEL_NAME = "Qwen/Qwen3-VL-2B-Instruct-GGUF"
QUANT = "Q4_K_M"

# last description of a "scene context" chunk, handed to later motion chunks as the "scene before"
BASELINE = dict(text="", ts_us=0)


class _VramPeak:
    """Polls nvidia-smi while a chunk is analysed. Reports total GPU memory in use (all processes), not just this model."""
    def __init__(self):
        self.peak, self._run = None, False

    def _loop(self):
        while self._run:
            try:
                v = float(subprocess.check_output(["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"], text=True, timeout=2).split()[0])
                self.peak = v if self.peak is None else max(self.peak, v)
            except Exception:
                pass
            time.sleep(0.5)

    def __enter__(self):
        self._run = True; self._t = threading.Thread(target=self._loop, daemon=True); self._t.start(); return self

    def __exit__(self, *a):
        self._run = False; self._t.join(timeout=2)


def _clock(ts_us):
    d = dt.datetime.fromtimestamp(ts_us / 1e6)
    return d.strftime("%H:%M:%S") + f".{d.microsecond // 1000:03d}"


def _encode(path, long_edge):
    img = cv2.imread(path)
    if img is None:
        raise ValueError(f"cannot decode {os.path.basename(path)}")
    h, w = img.shape[:2]
    s = long_edge / max(h, w)
    if s < 1:
        img = cv2.resize(img, (round(w * s), round(h * s)), interpolation=cv2.INTER_AREA)
    ok, jpg = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return "data:image/jpeg;base64," + base64.b64encode(jpg.tobytes()).decode(), img.shape[1], img.shape[0]


def validate(event_dir, meta):
    """Returns (frames, issues). Frames: list of dict(file, ts_us) with decodable files and non-decreasing timestamps."""
    issues, out, last = [], [], None
    for f in meta.get("frames", []):
        p = os.path.join(event_dir, f["file"])
        if not os.path.exists(p):
            issues.append(f"missing file {f['file']}"); continue
        if last is not None and f["ts_us"] < last:
            issues.append(f"timestamp order violated at {f['file']}"); continue
        last = f["ts_us"]
        out.append(dict(file=f["file"], path=p, ts_us=f["ts_us"]))
    return out, issues


def make_windows(frames, window_s=WINDOW_S, max_frames=MAX_FRAMES):
    t0 = frames[0]["ts_us"]
    wins, w = [], 0
    while True:
        a, b = t0 + int(w * window_s * 1e6), t0 + int((w + 1) * window_s * 1e6)
        inw = [f for f in frames if a <= f["ts_us"] < b]
        if not inw and a > frames[-1]["ts_us"]:
            break
        if inw:
            k = min(max_frames, len(inw))
            idx = [round(i * (len(inw) - 1) / max(k - 1, 1)) for i in range(k)] if k > 1 else [0]
            wins.append(dict(id=f"w{len(wins):03d}", start_s=(a - t0) / 1e6, end_s=min((b - t0) / 1e6, (frames[-1]["ts_us"] - t0) / 1e6 + 1e-3),
                             frames=[inw[i] for i in sorted(set(idx))], n_in_window=len(inw)))
        w += 1
    return wins


def _window_request(win, t0, mode, is_context, baseline, long_edge, n_frames):
    fr = win["frames"]
    if n_frames < len(fr):                                    # fallback: fewer frames, still evenly spread
        keep = sorted({round(i * (len(fr) - 1) / max(n_frames - 1, 1)) for i in range(n_frames)}) if n_frames > 1 else [0]
        fr = [fr[i] for i in keep]
    text = prompts.PROMPTS[mode]
    text += f"\nThe {len(fr)} frames below are in chronological order, taken between +{win['start_s']:.1f} s and +{win['end_s']:.1f} s of a clip that started at {_clock(t0)}."
    if is_context:
        text += "\n" + prompts.CONTEXT_NOTE
    elif baseline.get("text"):
        ago = f"{max(0, (t0 - baseline['ts_us']) / 1e6):.0f} s before this clip"
        text += "\n" + prompts.BASELINE_NOTE.format(ago=ago, text=baseline["text"])
    content = [{"type": "text", "text": text}]
    dims = []
    for f in fr:
        url, w, h = _encode(f["path"], long_edge)
        dims.append((w, h))
        content.append({"type": "text", "text": f"Frame at +{(f['ts_us'] - t0) / 1e6:.2f} s ({_clock(f['ts_us'])}):"})
        content.append({"type": "image_url", "image_url": {"url": url}})
    return [{"role": "system", "content": prompts.SYSTEM}, {"role": "user", "content": content}], fr, dims


def _infer_window(win, t0, mode, is_context, baseline):
    """Bounded fallback ladder: full -> half the frames -> half the frames at 224 px. Returns (text, used) or raises."""
    ladder = [(len(win["frames"]), LONG_EDGE), (max(1, len(win["frames"]) // 2), LONG_EDGE), (max(1, len(win["frames"]) // 2), 224)]
    last = None
    for n, edge in ladder:
        try:
            msgs, fr, dims = _window_request(win, t0, mode, is_context, baseline, edge, n)
            text, usage = server.chat(msgs)
            if not text:
                raise RuntimeError("empty model output")
            return text, dict(frames=len(fr), long_edge=edge, size=list(dims[0]) if dims else None, prompt_tokens=usage.get("prompt_tokens"),
                              frame_files=[f["file"] for f in fr], timestamps_s=[round((f["ts_us"] - t0) / 1e6, 2) for f in fr])
        except Exception as e:
            last = e
    raise RuntimeError(f"window failed after fallbacks: {last!r}")


def _synthesize(observations, coverage_note):
    lines = [f"[{o['window_id']}] +{o['interval_s'][0]:.1f}-{o['interval_s'][1]:.1f} s: {o['description']}" for o in observations]
    text = prompts.SYNTHESIS + "\n\nWindow observations (chronological):\n" + "\n".join(lines) + "\n\nCoverage: " + coverage_note
    out, _ = server.chat([{"role": "system", "content": prompts.SYSTEM}, {"role": "user", "content": text}], max_tokens=320)
    return out


def analyze_chunk(event_dir, meta, baseline=None, mode="rgb"):
    t_start = time.time()
    baseline = BASELINE if baseline is None else baseline
    is_context = meta.get("kind") == "context"
    rep = dict(request_id=f"event_{meta.get('event_id'):04d}" if isinstance(meta.get("event_id"), int) else str(meta.get("event_id")),
               requested_mode=mode, effective_mode=mode, status="failed", model=MODEL_NAME, quantization=QUANT, prompt_version=prompts.PROMPT_VERSION,
               kind=meta.get("kind", "motion"), summary="", timeline=[], limitations=[], coverage={}, windows=[],
               runtime=dict(cpu_offload_used=False, peak_gpu_mem_used_mib=None, elapsed_seconds=None))
    lim = ["General vision model (2B, 4-bit); descriptions can be wrong, details may be missed.",
           "Frames are passed as ordered, timestamp-labelled images (multi-image approximation, not native video).",
           "Sampled at most %d frames per %.0f s window; brief actions between samples can be missed." % (MAX_FRAMES, WINDOW_S),
           "Timestamps are laptop-clock times when each frame was read from the camera."]
    if mode != "rgb":
        rep["limitations"] = ["mode %s is not wired to the board yet" % mode]
        rep["error"] = f"mode {mode} not implemented"
        return rep
    frames, issues = validate(event_dir, meta)
    rep["limitations"] = lim + issues
    if not frames:
        rep["error"] = "no usable frames: " + ("; ".join(issues) or "chunk is empty")
        rep["runtime"]["elapsed_seconds"] = round(time.time() - t_start, 2)
        return rep
    t0 = frames[0]["ts_us"]
    wins = make_windows(frames)
    obs, failed, processed = [], [], []
    with _VramPeak() as vp, server.GPU_LOCK:
        server.STATE["busy"] = True
        try:
            for w in wins:
                try:
                    text, used = _infer_window(w, t0, mode, is_context, baseline)
                    obs.append(dict(window_id=w["id"], interval_s=[round(w["start_s"], 2), round(w["end_s"], 2)], description=text, **used))
                    processed.append([round(w["start_s"], 2), round(w["end_s"], 2)])
                except Exception as e:
                    failed.append([round(w["start_s"], 2), round(w["end_s"], 2)])
                    rep["limitations"].append(f"{w['id']} failed: {e}")
            if len(obs) == 1:
                rep["summary"] = obs[0]["description"]
            elif obs:
                try:
                    rep["summary"] = _synthesize(obs, f"processed {processed}; missing {failed}")
                except Exception as e:
                    rep["summary"] = " ".join(o["description"] for o in obs)
                    rep["limitations"].append(f"synthesis failed ({e!r}); window descriptions concatenated")
        finally:
            server.STATE["busy"] = False
    rep["timeline"] = [dict(window_id=o["window_id"], interval_s=o["interval_s"], description=o["description"],
                            clock=[_clock(t0 + int(o["interval_s"][0] * 1e6)), _clock(t0 + int(o["interval_s"][1] * 1e6))]) for o in obs]
    rep["windows"] = [{k: v for k, v in o.items() if k not in ("description",)} for o in obs]
    rep["coverage"] = dict(chunk_start_ts_us=t0, chunk_start_clock=_clock(t0), requested_interval_s=[0.0, round((frames[-1]["ts_us"] - t0) / 1e6, 2)],
                           processed_intervals_s=processed, missing_intervals_s=failed,
                           sampled_frame_timestamps_s=[t for o in obs for t in o["timestamps_s"]], audio_processed=False,
                           frames_in_chunk=len(meta.get("frames", [])), frames_used=len(frames))
    rep["status"] = "failed" if not obs else ("partial" if failed or issues else "completed")
    if not obs:
        rep["error"] = "no window could be analysed"
    rep["runtime"].update(peak_gpu_mem_used_mib=vp.peak, elapsed_seconds=round(time.time() - t_start, 2))
    if rep["status"] != "failed" and is_context:
        BASELINE.update(text=rep["summary"], ts_us=frames[-1]["ts_us"])
    return rep


def to_markdown(rep):
    L = [f"# Scene report {rep.get('request_id')} ({rep.get('kind')}) - {rep.get('status')}", "", rep.get("summary") or rep.get("error", ""), "", "## Timeline"]
    for t in rep.get("timeline", []):
        L.append(f"- +{t['interval_s'][0]:.1f}-{t['interval_s'][1]:.1f} s ({t['clock'][0]}-{t['clock'][1]}): {t['description']}")
    c = rep.get("coverage", {})
    L += ["", "## Coverage", f"- processed {c.get('processed_intervals_s')} of {c.get('requested_interval_s')} s; missing {c.get('missing_intervals_s')}",
          f"- sampled frames at +{c.get('sampled_frame_timestamps_s')} s; audio processed: {c.get('audio_processed')}", "", "## Limitations"]
    L += [f"- {x}" for x in rep.get("limitations", [])]
    r = rep.get("runtime", {})
    L += ["", f"Runtime: {r.get('elapsed_seconds')} s, peak GPU memory in use {r.get('peak_gpu_mem_used_mib')} MiB (all processes), prompt {rep.get('prompt_version')}."]
    return "\n".join(L)
